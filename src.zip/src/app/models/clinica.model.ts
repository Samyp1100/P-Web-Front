export interface Clinica {
  identificador?: number;
  nombre: string;
  direccion: string;
  cantidadCamas: number;
  telefono: string;
  correo: string;
  fechaCreacion: string;
}
